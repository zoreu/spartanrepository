# -*- coding: utf-8 -*-
try:
    from resources.modules.helper import *
except ImportError:
    from helper import *

server_update = 'http://zoreu.serv00.net:58454'
ativar_update = True

    
def list_files():
    headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0'}
    try:
        lista = server_update + '/listupdate'
        r = requests.get(lista,headers=headers)
        if r.status_code == 200:
            files = r.json()
        else:
            files = []
            log('UPDATE: erro ao acessar %s'%lista)
    except:
        files = []
    return files  
    
def atualizar_addon():
    headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0'}
    ver_file = translate('special://home/addons/plugin.video.spartanaddon/update.txt')
    if os.path.exists(ver_file):
        with open(ver_file, 'r') as f:
            ver_base = f.read()
            if ativar_update:
                try:
                    url_update_file = server_update + '/update/plugin.video.spartanaddon/update.txt'
                    r = requests.get(url_update_file,headers=headers)
                    if r.status_code == 200:
                        ver_site = r.text
                        if ver_site:
                            if ver_site != ver_base:
                                notify('Atualizando...')
                                files = list_files()
                                # baixar arquivo por arquivo
                                for i in files:
                                    d = translate('special://home/addons' + i)
                                    url_file = server_update + '/update' + i
                                    with open(d, 'wb') as f:
                                        log('UPDATE: acessando %s'%url_file)
                                        res = requests.get(url_file,headers=headers,stream=True)
                                        if res.status_code == 200:
                                            for chunk in res.iter_content(chunk_size=1024):
                                                f.write(chunk)
                                        else:
                                            log('UPDATE: falha ao acessar %s'%url_file)
                                # salvar update.txt
                                try:
                                    d = translate('special://home/addons/plugin.video.spartanaddon/update.txt')
                                    with open(d, 'wb') as f:
                                        log('UPDATE: acessando %s'%url_update_file)
                                        res = requests.get(url_update_file,headers=headers,stream=True)
                                        if res.status_code == 200:
                                            for chunk in res.iter_content(chunk_size=1024):
                                                f.write(chunk)
                                        else:
                                            log('UPDATE: falha ao acessar %s'%url_update_file)
                                except:
                                    log('UPDATE: Erro ao baixar update.txt')
                                notify('Atualizado com sucesso')
                    else:
                        log('UPDATE: url %s nao existe'%url_update_file)             
                except:
                    pass

